import java.util.Arrays;

import com.conv.free.dao.FreeDAO;
import com.conv.free.domain.Free;

public class TestPage {
	public static void main(String[] args) {
		FreeDAO dao = new FreeDAO();
		
		Free f = new Free();
		
		
		
//		f.setState(0);
//		f.setTitle("라멘 4+1");
//		f.setContent("허기진사람 나눔합니다");
//		f.setWriter("면장사");
//		f.setHits(10);
//		
//		dao.insertBoard(f);
		
//		f.setState("완료");
//		f.setTitle("나눌게없네요");
//		f.setContent("나눔끝");
//		f.setNo(4);
//		
//		dao.updateBoard(f);
	}
}
