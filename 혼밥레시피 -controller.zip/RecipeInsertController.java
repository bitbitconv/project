package com.conv.recipe.controller;

import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

import com.conv.recipe.dao.RecipeDAO;
import com.conv.recipe.domain.Recipe;


@WebServlet("/com/conv/recipe/controller/recipeinsertcontroller")
public class RecipeInsertController extends GenericServlet {

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
//		String id=  request.getParameter("id");
		String title=  request.getParameter("title");
		String content=  request.getParameter("content");
//		String photo=  request.getParameter("photo");
		
		
		Recipe vo= new Recipe();
//		vo.setId(id);
		vo.setContent(content);
		vo.setTitle(title);
//		vo.setPhoto(photo);
		
		RecipeDAO dao = new RecipeDAO();
		dao.insertRecipe(vo);
		
//		System.out.println("id : " + id);
		System.out.println("title : " + title);
		System.out.println("content : " + content);
//		System.out.println("photo : " + photo);
	
		
		
	}
	
	


}
