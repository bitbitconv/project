package com.conv.recipe.controller;

import java.io.IOException;

import javax.jws.WebService;
import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

import com.conv.recipe.dao.RecipeDAO;
import com.conv.recipe.domain.Recipe;

@WebServlet("/com/conv/recipe/controller/recipeupdatecontroller")
public class RecipeUpdateController extends GenericServlet{

	
	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
		int no=  Integer.parseInt(request.getParameter("no"));
		String title=  request.getParameter("title");
		String content=  request.getParameter("content");
		
		
		Recipe vo= new Recipe();
		vo.setNo(no);
		vo.setContent(content);
		vo.setTitle(title);
		
		RecipeDAO dao = new RecipeDAO();
		dao.updateRecipe(vo);
		
		System.out.println("no : " + no);
		System.out.println("title : " + title);
		System.out.println("content : " + content);
	
		
		
	}
	
}
