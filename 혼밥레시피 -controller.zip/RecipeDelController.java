package com.conv.recipe.controller;

import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

import com.conv.recipe.dao.RecipeDAO;
import com.conv.recipe.domain.Recipe;

@WebServlet("/com/conv/recipe/controller/recipedelcontroller")


public class RecipeDelController extends GenericServlet {
	
	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		
		int no = Integer.parseInt(request.getParameter("no"));		
		Recipe vo= new Recipe();
		vo.setNo(no);
		
		RecipeDAO dao = new RecipeDAO();
		dao.deleteRecipe(no);
		
		System.out.println("no : " + no);
	
		
		
	}
	
	


	
	
}
