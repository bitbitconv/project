package kr.co.mlec.util;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class JdbcUtil {
	public static void close(PreparedStatement stmt) {
		close(stmt,null);
	}

	public static void close(PreparedStatement stmt,Connection con) {
		if(stmt != null) {
			try {
				stmt.close();
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				try {
					if(con != null) {
						con.close();
					}
					
				}catch(Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
}
