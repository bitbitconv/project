package kr.co.mlec.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;

public class ConnectionPool {
	private static final int INIT_COUNT = 5;  // 초기 카운트수 5개로 설정.
	private static List<Connection> free = new ArrayList<>(); // 사용하지 않는 것
	private static List<Connection> used = new ArrayList<>(); // 사용중인것.
	
	static {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			for(int i =0; i<INIT_COUNT ; i++) {
				Connection con = DriverManager.getConnection
						("jdbc:oracle:thin:@localhost:1521:XE","hr","hr"); 
				//INIT_COUNT 만큼 커넥션을 맺어야한다.
				free.add(con); //free  라는 리스트에 커넥션 추가
			}
		}catch(Exception e) {
			System.out.println("초기 풀 생성시 오류 발생");
			e.printStackTrace();
		}
	}

	public static Connection getConnection() throws Exception{
		if(free.isEmpty()) { //  비어있다면 현재 모든 커넥션 사용중
			throw new Exception("모든 커넥션이 사용중입니다.");
			
		}
		
		Connection con = free.remove(0); // free 리스트의 0번째 데이터를 con 에 넣고 free 0번은 지움.
		used.add(con); // free 에서 사용하지 않는 걸 con 으로넘겨받은후  사용중으로 넘겨줌. 
		return con ; // 요청한 쪽으로 리턴
	}
	
	
	public static void releaseConnection(Connection con) {
		used.remove(con);
		free.add(con);  //used 에 공간이 다차면 used 에서 지워주고 free 에 다시 넣어준다.
	}
	public static void main(String[] args) {
		try {
			for(int i = 0; i < 10 ; i++) {
				System.out.println( i + 1 +"번째요청");
				Thread.sleep(1000);
				Connection con = ConnectionPool.getConnection();
				// 커넥션 풀한테 달라고 요청하면 커넥션이 줄것임.
				System.out.println(con);
				ConnectionPool.releaseConnection(con);//  커넥션 반환하지 않으면 5개 만 쓸수있다.
			}			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
